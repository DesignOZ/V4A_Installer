#!/system/bin/sh
setenforce 0
