#! /system/bin/sh
echo "V4A script ran." > /data/v4a_script.txt
/su/bin/supolicy --live "allow mediaserver mediaserver_tmpfs:file { read write execute };"
